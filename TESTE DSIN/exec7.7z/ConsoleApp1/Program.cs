﻿using System;

class Program
{
    static void Main()
    {
        string texto = "Texto centralizado na caixa!";
        DesenharCaixaComTextoCentralizado(texto);
    }

    static void DesenharCaixaComTextoCentralizado(string texto)
    {
        int larguraTotal = texto.Length + 4; 
        int espacosAntes = (larguraTotal - texto.Length) / 2;

        string linhaSuperior = new string('|', larguraTotal + 2);
        string linhaVazia = $"||{new string(' ', larguraTotal - 2)}||";
        string linhaTexto = $"||{new string(' ', espacosAntes)}{texto}{new string(' ', larguraTotal - espacosAntes - texto.Length - 2)}||";
        string linhaInferior = new string('|', larguraTotal + 2);

        Console.WriteLine(linhaSuperior);
        Console.WriteLine(linhaVazia);
        Console.WriteLine(linhaTexto);
        Console.WriteLine(linhaVazia);
        Console.WriteLine(linhaInferior);
    }
}
