﻿using System;
using System.Text.RegularExpressions;

class Program
{
    static void Main()
    {
        Console.Write("Digite a placa do veículo: ");
        string placa = Console.ReadLine().ToUpper();

        if (ValidarPlaca(placa))
        {
            string padrao = DeterminarPadrao(placa);
            string correspondente = ConverterPlaca(placa, padrao);

            Console.WriteLine($"Padrão: {padrao}");
            Console.WriteLine($"Correspondente: {correspondente}");
        }
        else
        {
            Console.WriteLine("Formato inválido");
        }
    }

    static bool ValidarPlaca(string placa)
    {
        Regex regex = new Regex(@"^[A-Z]{3}\d{4}$|^[A-Z]{3}\d[A-Z]\d{2}$");
        return regex.IsMatch(placa);
    }

    static string DeterminarPadrao(string placa)
    {
        char quintoCaractere = placa[4];

        if (char.IsLetter(quintoCaractere))
        {
            return "Mercosul";
        }
        else if (char.IsNumber(quintoCaractere))
        {
            return "Brasil (Antigo)";
        }
        else
        {
            return "Desconhecido";
        }
    }

    static string ConverterPlaca(string placa, string padraoAtual)
    {
        char[] caracteres = placa.ToCharArray();

        if (padraoAtual == "Brasil (Antigo)")
        {
            caracteres[4] = ConverterNumeroParaLetra(caracteres[4]);
        }
        else
        {
            caracteres[4] = ConverterLetraParaNumero(caracteres[4]); 
        }

        return new string(caracteres);
    }

    static char ConverterNumeroParaLetra(char numero)
    {
        int valor = int.Parse(numero.ToString()); 
        return (char)(valor + 'A'); 
    }


    static char ConverterLetraParaNumero(char letra)
    {
        int valor = char.ToUpper(letra) - 'A'; 
        return (char)(valor + '0'); 
    }

}
