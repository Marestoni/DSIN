﻿using System;

class Program
{
    static void Main()
    {
        
        Console.Write("Valor de A: ");
        int A = Convert.ToInt32(Console.ReadLine());

        Console.Write("Valor de B: ");
        int B = Convert.ToInt32(Console.ReadLine());

        Console.Write("Valor de C: ");
        int C = Convert.ToInt32(Console.ReadLine());

        if (A == 0 && B == 0 && C != 1)
        {
            Console.WriteLine("Solução impossível");
        }
        else
        {
            double X = (1.0 - C) / (A + B);

            Console.WriteLine($"O valor de X é: {X}");
        }
    }
}
