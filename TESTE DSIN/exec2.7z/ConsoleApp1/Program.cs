﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Digite quatro valores inteiros (A, B, C, D):");

        // Recebendo os valores
        Console.Write("Valor de A: ");
        int A = Convert.ToInt32(Console.ReadLine());

        Console.Write("Valor de B: ");
        int B = Convert.ToInt32(Console.ReadLine());

        Console.Write("Valor de C: ");
        int C = Convert.ToInt32(Console.ReadLine());

        Console.Write("Valor de D: ");
        int D = Convert.ToInt32(Console.ReadLine());

        if (B > C && D > A && (C + D) > (A + B) && C > 0 && D > 0 && A % 2 == 0)
        {
            Console.WriteLine("Valores aceitos");
        }
        else
        {
            Console.WriteLine("Valores não aceitos");
        }
    }
}