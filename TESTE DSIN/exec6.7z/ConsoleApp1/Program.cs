﻿using System;

class Program
{
    static void Main()
    {
        int N = 100; 

        for (int i = 1; i <= N; i++)
        {
            if (NumeroPerfeito(i))
                Console.WriteLine($"{i} é número perfeito");
            if (MultiploDe(i, 2))
                Console.WriteLine($"{i} é múltiplo de 2");
            if (MultiploDe(i, 7))
                Console.WriteLine($"{i} é múltiplo de 7");
            if (NumeroPrimo(i))
                Console.WriteLine($"{i} é número primo");
        }
    }

    static bool NumeroPerfeito(int num)
    {
        int soma = 0;
        for (int i = 1; i <= num / 2; i++)
        {
            if (num % i == 0)
                soma += i;
        }
        return soma == num;
    }

    static bool MultiploDe(int num, int divisor)
    {
        return num % divisor == 0;
    }

    static bool NumeroPrimo(int num)
    {
        if (num <= 1)
            return false;
        for (int i = 2; i <= Math.Sqrt(num); i++)
        {
            if (num % i == 0)
                return false;
        }
        return true;
    }
}
