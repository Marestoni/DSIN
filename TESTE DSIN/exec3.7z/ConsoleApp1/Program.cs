﻿using System;

class Program
{
    static void Main()
    {
        
        Console.Write("Digite do item: ");
        string descricao = Console.ReadLine();

        Console.Write("Digite a quantidade do item: ");
        int quantidade = Convert.ToInt32(Console.ReadLine());

        Console.Write("Preço por item: ");
        double precoPorUnidade = Convert.ToDouble(Console.ReadLine());

        double totalSemDesconto = quantidade * precoPorUnidade;

        double desconto = 0;

        if (quantidade <= 5)
        {
            desconto = totalSemDesconto * 0.0555;
        }
        else if (quantidade > 5 && quantidade <= 10)
        {
            desconto = totalSemDesconto * 0.08;
        }
        else
        {
            desconto = totalSemDesconto * 0.125;
        }

        double totalAPagar = totalSemDesconto - desconto;

        Console.WriteLine($"Descrição: {descricao}");
        Console.WriteLine($"QTD: {quantidade}");
        Console.WriteLine($"Preço por item: R${precoPorUnidade:F2}");
        Console.WriteLine($"Total: R${totalSemDesconto:F2}");
        Console.WriteLine($"Desconto: R${desconto:F2}");
        Console.WriteLine($"Total: R${totalAPagar:F2}");
    }
}
