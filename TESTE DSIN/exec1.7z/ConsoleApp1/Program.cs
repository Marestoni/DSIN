﻿using System;

namespace CalculoSalario
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.Write("Horas por dia: ");
            int horasPorDia = Convert.ToInt32(Console.ReadLine());

            Console.Write("Preço por hora trabalhada: ");
            double precoHora = Convert.ToDouble(Console.ReadLine());

            Console.Write("Dias trabalhados no mês: ");
            int diasTrabalhados = Convert.ToInt32(Console.ReadLine());

            double salBruto = horasPorDia * precoHora * diasTrabalhados;

            double desconto = salBruto * 0.21;

            double salLiquido = salBruto - desconto;

            Console.WriteLine($"Sal bruto: R${salBruto:F2}");
            Console.WriteLine($"Desc (21%): R${desconto:F2}");
            Console.WriteLine($"Sal líquido: R${salLiquido:F2}");

            Console.ReadKey();
        }
    }
}
